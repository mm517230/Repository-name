澳彩 AI 智能助手 Android 工程（V1.3）

本压缩包是可用 Android Studio 打开的安卓项目源码，不是已经编译、签名的 APK 安装包。

工程内容
- app/src/main/assets/index.html：内置 V1.3 网页应用，离线加载。
- MainActivity.kt：Android WebView 容器，启用 JavaScript 和本地存储。
- 应用名称：澳彩 AI 智能助手
- applicationId：com.aocai.assistant
- versionName：1.3
- 最低 Android：Android 6.0（API 23）

如何生成 APK
1. 在电脑安装 Android Studio（建议最新版）及 Android SDK Platform 35。
2. 解压本压缩包，在 Android Studio 选择 Open，打开解压后的 AocaiAssistant 文件夹。
3. 等待 Gradle Sync 完成；如提示安装 Android SDK Build-Tools，请按提示安装。
4. 选择 Build > Build Bundle(s) / APK(s) > Build APK(s)。
5. 成功后 APK 通常位于 app/build/outputs/apk/debug/app-debug.apk。
6. 将 APK 传到安卓手机，允许该来源安装应用后安装。

注意
- 本工程尚未在真实安卓设备上安装测试，也未在本环境编译 APK。
- 下注记录使用 WebView 本机 localStorage 保存；清除应用数据或卸载应用可能导致本机记录丢失，建议定期导出备份。
- 官方开奖联网同步、云端备份和手机推送仍未接入。
- 请先用示例投注核对计算金额和盈亏，再用于实际记录。
